# Rapport d'Audit Nexus Prime - Mocks et Valeurs Hardcodées

## Backend (Rust)
- **`types.rs`**: 
    - Méthode `AiPickResponse::mock_for` : Génère des réponses avec des probabilités et des mises basées sur des profils de risque codés en dur.
    - Valeurs comme `base_conf`, `stake`, `edge_percent` (4.2), `model_version` ("nexus-ia-pronos-2026") sont simulées.
- **`main.rs`**:
    - Endpoint `/api/picks` : Appelle `AiPickResponse::mock_for`.
    - Endpoint `/api/ai/explain` : Retourne un JSON statique avec "explanation" et "version".
    - `dark_theme_header` : Valeur statique "dark-amoled-2026".
- **`ws.rs`**:
    - Message de bienvenue "hello" avec des valeurs statiques.
    - La boucle de diffusion des signaux n'est pas encore implémentée avec de vraies données (utilise un canal de broadcast vide ou simulé dans `main.rs`).

## Frontend (Next.js)
- **`LiveSignals.tsx`**:
    - Constante `MOCK_SIGNALS` : Liste statique de signaux.
    - `useEffect` : Simule l'arrivée de nouveaux signaux avec `setInterval` et `Math.random()`.
- **`PicksSection.tsx`**:
    - Constante `MOCK_PICKS` : Liste statique de pronostics.
    - Fonction `generateNewPick` : Simule un chargement de 1s sans appeler d'API réelle.
- **`Hero.tsx`** (à vérifier) : Probablement des statistiques statiques (utilisateurs, winrate).

## Dépendances (Cargo.toml)
- Nécessite l'ajout de `ort` ou `tract-onnx` pour l'inférence.
- Nécessite `reqwest` pour les appels API externes (OpticOdds).
- Nécessite `serde_json` (déjà présent probablement).

## Dépendances (package.json)
- Vérifier si `framer-motion` et `lucide-react` sont bien installés.
