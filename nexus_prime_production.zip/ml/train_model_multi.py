import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, log_loss
import onnx
from skl2onnx import convert_sklearn
from skl2onnx.common.data_types import FloatTensorType
import os

def generate_league_data(league_name, n_samples=2000):
    np.random.seed(hash(league_name) % 2**32)
    # Features: home_form, away_form, h2h, rank_diff
    X = np.random.rand(n_samples, 4)
    X[:, 3] = np.random.randint(-20, 20, n_samples)
    
    # Specific league characteristics
    if league_name == "premier_league":
        # High home advantage
        prob = 0.35 + 0.25*X[:, 0] - 0.15*X[:, 1] + 0.1*X[:, 2] - 0.01*X[:, 3]
    elif league_name == "ligue1":
        # More draws, less predictable
        prob = 0.3 + 0.2*X[:, 0] - 0.2*X[:, 1] + 0.1*X[:, 2] - 0.008*X[:, 3]
    else:
        prob = 0.3 + 0.22*X[:, 0] - 0.18*X[:, 1] + 0.12*X[:, 2] - 0.01*X[:, 3]
        
    prob = np.clip(prob, 0.01, 0.99)
    y = (np.random.rand(n_samples) < prob).astype(int)
    odds = 1.0 / (prob * 0.95)
    return X, y, odds

leagues = ["premier_league", "ligue1", "laliga", "bundesliga", "seriea"]
os.makedirs("/home/ubuntu/nexus-prime-web-local/ml/models", exist_ok=True)

print(f"{'League':<15} | {'Acc':<6} | {'Loss':<6} | {'ROI':<7} | {'Samples':<8}")
print("-" * 55)

for league in leagues:
    X, y, odds = generate_league_data(league)
    X_train, X_test, y_train, y_test, _, odds_test = train_test_split(
        X, y, odds, test_size=0.2, random_state=42
    )
    
    model = RandomForestClassifier(n_estimators=100, max_depth=5, random_state=42)
    model.fit(X_train, y_train)
    
    y_pred_proba = model.predict_proba(X_test)[:, 1]
    y_pred = (y_pred_proba > 0.5).astype(int)
    
    acc = accuracy_score(y_test, y_pred)
    loss = log_loss(y_test, y_pred_proba)
    
    # ROI Simulation
    bets = y_pred_proba > (1.0 / odds_test)
    total_bets = np.sum(bets)
    returns = np.sum(odds_test[(y_test == 1) & bets])
    roi = ((returns - total_bets) / total_bets * 100) if total_bets > 0 else 0
    
    print(f"{league:<15} | {acc:.4f} | {loss:.4f} | {roi:>6.2f}% | {len(X):<8}")
    
    # Export
    initial_type = [('float_input', FloatTensorType([None, 4]))]
    onx = convert_sklearn(model, initial_types=initial_type, target_opset=12)
    with open(f"/home/ubuntu/nexus-prime-web-local/ml/models/{league}.onnx", "wb") as f:
        f.write(onx.SerializeToString())
