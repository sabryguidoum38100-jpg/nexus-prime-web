import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, log_loss
import onnx
from skl2onnx import convert_sklearn
from skl2onnx.common.data_types import FloatTensorType
import os

data_files = {
    "premier_league": "pl_2425.csv",
    "ligue1": "l1_2425.csv",
    "laliga": "sp1_2425.csv",
    "bundesliga": "d1_2425.csv",
    "seriea": "i1_2425.csv"
}

os.makedirs("/home/ubuntu/nexus-prime-web-local/ml/models", exist_ok=True)

def process_and_train(league, file_path):
    df = pd.read_csv(f"/home/ubuntu/nexus-prime-web-local/ml/data/{file_path}")
    
    # Features: HomeOdds (PSH), DrawOdds (PSD), AwayOdds (PSA), HomeGoals (FTHG), AwayGoals (FTAG)
    # We use Pinnacle odds as features because they are the most efficient
    df = df[['PSH', 'PSD', 'PSA', 'FTHG', 'FTAG', 'FTR']].dropna()
    
    # Target: Home Win (1) or Not (0)
    y = (df['FTR'] == 'H').astype(int)
    
    # Features: Odds and historical goal diff
    X = df[['PSH', 'PSD', 'PSA']].values.astype(np.float32)
    
    X_train, X_test, y_train, y_test, odds_train, odds_test = train_test_split(
        X, y, df['PSH'].values, test_size=0.2, random_state=42
    )
    
    model = RandomForestClassifier(n_estimators=150, max_depth=6, random_state=42)
    model.fit(X_train, y_train)
    
    y_pred_proba = model.predict_proba(X_test)[:, 1]
    acc = accuracy_score(y_test, (y_pred_proba > 0.5).astype(int))
    loss = log_loss(y_test, y_pred_proba)
    
    # ROI Simulation (Bet if model_prob > bookie_prob)
    bookie_prob = 1.0 / odds_test
    bets = y_pred_proba > (bookie_prob + 0.02) # Edge > 2%
    total_bets = np.sum(bets)
    returns = np.sum(odds_test[(y_test == 1) & bets])
    roi = ((returns - total_bets) / total_bets * 100) if total_bets > 0 else 0
    
    print(f"{league:<15} | {acc:.4f} | {loss:.4f} | {roi:>6.2f}% | {len(df):<8}")
    
    # Export ONNX
    initial_type = [('float_input', FloatTensorType([None, 3]))]
    onx = convert_sklearn(model, initial_types=initial_type, target_opset=12)
    with open(f"/home/ubuntu/nexus-prime-web-local/ml/models/{league}.onnx", "wb") as f:
        f.write(onx.SerializeToString())

print(f"{'League':<15} | {'Acc':<6} | {'Loss':<6} | {'ROI':<7} | {'Samples':<8}")
print("-" * 55)

for league, file in data_files.items():
    try:
        process_and_train(league, file)
    except Exception as e:
        print(f"Error training {league}: {e}")
