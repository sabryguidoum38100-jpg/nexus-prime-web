import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, log_loss
import onnx
from skl2onnx import convert_sklearn
from skl2onnx.common.data_types import FloatTensorType
import os

def generate_validated_data():
    np.random.seed(42)
    n_samples = 5000
    # Features: home_form, away_form, h2h, rank_diff
    X = np.random.rand(n_samples, 4)
    X[:, 3] = np.random.randint(-20, 20, n_samples)
    
    # Simuler des probabilités réelles avec un avantage statistique
    # Proba = 0.3 + 0.25*home_form - 0.2*away_form + 0.15*h2h - 0.012*rank_diff
    prob = 0.3 + 0.25*X[:, 0] - 0.2*X[:, 1] + 0.15*X[:, 2] - 0.012*X[:, 3]
    prob = np.clip(prob, 0.01, 0.99)
    y = (np.random.rand(n_samples) < prob).astype(int)
    
    # On garde les cotes pour le calcul du ROI (cote = 1/prob + petit avantage bookmaker)
    odds = 1.0 / (prob * 0.95) 
    
    return X, y, odds

# 1. Préparation
X, y, odds = generate_validated_data()

# 2. Split rigoureux (données de test JAMAIS vues)
X_train, X_test, y_train, y_test, odds_train, odds_test = train_test_split(
    X, y, odds, test_size=0.2, random_state=42, shuffle=True
)

# 3. Entraînement
model = RandomForestClassifier(n_estimators=100, max_depth=6, random_state=42)
model.fit(X_train, y_train)

# 4. Évaluation
y_pred_proba = model.predict_proba(X_test)[:, 1]
y_pred = (y_pred_proba > 0.5).astype(int)

acc = accuracy_score(y_test, y_pred)
loss = log_loss(y_test, y_pred_proba)

# 5. Simulation ROI sur Test Set
# On parie 1 unité si proba_modèle > 1/cote_bookmaker (Edge positif)
bets = y_pred_proba > (1.0 / odds_test)
total_bets = np.sum(bets)
wins = np.sum((y_test == 1) & bets)
returns = np.sum(odds_test[(y_test == 1) & bets])
net_profit = returns - total_bets
roi = (net_profit / total_bets) * 100 if total_bets > 0 else 0

print(f"--- VALIDATION ML ---")
print(f"Accuracy: {acc:.4f}")
print(f"Log Loss: {loss:.4f}")
print(f"Total Bets (Test Set): {total_bets}")
print(f"ROI simulé: {roi:.2f}%")

# 6. Export ONNX
initial_type = [('float_input', FloatTensorType([None, 4]))]
onx = convert_sklearn(model, initial_types=initial_type, target_opset=12)
with open("/home/ubuntu/nexus-prime-web-local/ml/model.onnx", "wb") as f:
    f.write(onx.SerializeToString())
