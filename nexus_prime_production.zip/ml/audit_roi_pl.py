import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split

def generate_league_data(league_name, n_samples=2000):
    np.random.seed(hash(league_name) % 2**32)
    X = np.random.rand(n_samples, 4)
    X[:, 3] = np.random.randint(-20, 20, n_samples)
    
    # Probabilité réelle (le terrain)
    prob = 0.35 + 0.25*X[:, 0] - 0.15*X[:, 1] + 0.1*X[:, 2] - 0.01*X[:, 3]
    prob = np.clip(prob, 0.01, 0.99)
    y = (np.random.rand(n_samples) < prob).astype(int)
    
    # Cotes du bookmaker (avec une marge de 5%)
    # On simule des cotes plus réalistes (moyenne autour de 2.0)
    odds = 1.0 / (prob * 0.95) 
    return X, y, odds

X, y, odds = generate_league_data("premier_league")
X_train, X_test, y_train, y_test, odds_train, odds_test = train_test_split(
    X, y, odds, test_size=0.2, random_state=42
)

model = RandomForestClassifier(n_estimators=100, max_depth=5, random_state=42)
model.fit(X_train, y_train)

y_pred_proba = model.predict_proba(X_test)[:, 1]

# Calcul de l'Edge : (Prob_modèle - Prob_implicite)
prob_implicite = 1.0 / odds_test
edges = (y_pred_proba - prob_implicite) * 100

# Filtre sur les paris sélectionnés (Edge > 0)
bets_mask = edges > 0
selected_edges = edges[bets_mask]
selected_odds = odds_test[bets_mask]
selected_results = y_test[bets_mask]

# Métriques demandées
n_edge_gt_5 = np.sum(selected_edges > 5)
avg_odds = np.mean(selected_odds)
total_bets = np.sum(bets_mask)
returns = np.sum(selected_odds[selected_results == 1])
roi = (returns - total_bets) / total_bets * 100

print(f"--- AUDIT ROI PREMIER LEAGUE ---")
print(f"Nombre total de paris : {total_bets}")
print(f"Nombre de paris avec Edge > 5% : {n_edge_gt_5}")
print(f"Cote moyenne des paris : {avg_odds:.2f}")
print(f"ROI final : {roi:.2f}%")
print(f"-------------------------------")
