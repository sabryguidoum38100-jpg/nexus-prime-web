import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import onnx
from skl2onnx import convert_sklearn
from skl2onnx.common.data_types import FloatTensorType
import os

# 1. Génération de données synthétiques réalistes pour l'exemple
def generate_data():
    print("Génération de données d'entraînement synthétiques...")
    n_samples = 2000
    # Features: home_form (0-1), away_form (0-1), h2h (0-1), rank_diff (-20 to 20)
    X = np.random.rand(n_samples, 4)
    X[:, 3] = np.random.randint(-20, 20, n_samples)
    
    # Target: Probabilité de victoire à domicile basée sur les features + bruit
    # Proba = 0.3 + 0.2*home_form - 0.15*away_form + 0.1*h2h - 0.01*rank_diff
    prob = 0.3 + 0.2*X[:, 0] - 0.15*X[:, 1] + 0.1*X[:, 2] - 0.01*X[:, 3]
    y = (prob + np.random.normal(0, 0.05, n_samples) > 0.5).astype(int)
    
    return X, y

# 2. Entraînement
X, y = generate_data()
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Utiliser un modèle simple pour la compatibilité ONNX
model = RandomForestClassifier(n_estimators=50, max_depth=3)
model.fit(X_train, y_train)

# 3. Évaluation
y_pred = model.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)
print(f"Accuracy: {accuracy:.4f}")

# 4. Export ONNX
# On utilise FloatTensorType pour correspondre aux f32 de Rust
initial_type = [('float_input', FloatTensorType([None, 4]))]
onx = convert_sklearn(model, initial_types=initial_type, target_opset=12)

os.makedirs("/home/ubuntu/nexus-prime-web-local/ml", exist_ok=True)
with open("/home/ubuntu/nexus-prime-web-local/ml/model.onnx", "wb") as f:
    f.write(onx.SerializeToString())

print("Modèle exporté avec succès dans /home/ubuntu/nexus-prime-web-local/ml/model.onnx")
